import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class SearchStudio extends JFrame {

    private JPanel contentPane;
    private JTextField textField;

    String[] columns= {"Name", "Address"};

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SearchStudio frame = new SearchStudio();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SearchStudio() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Search person by name: ");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel.setBounds(63, 20, 205, 42);
        contentPane.add(lblNewLabel);
        textField = new JTextField();
        textField.setBounds(278, 20, 163, 42);
        contentPane.add(textField);
        textField.setColumns(10);
        JButton btnNewButton = new JButton("Search");


        Database d = new Database();
        ArrayList<String> studioNames = d.getStudio();
        String[] names = new String[studioNames.size()];
        int index = studioNames.size();
        String[][] data1 =new String[index][2];
        int i = 0;
        while (i<index){
            String added = studioNames.get(i);
            names[i] = added;
            ArrayList<String> movie = d.getStudioo(added);
            data1[i][0] = names[i];
            data1[i][1] = movie.get(0);
            i+=1;
        }

        JTable table =new JTable(data1, columns);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                int i=0;
                int index = studioNames.size();
                while(i<index){
                    if (name.equals(studioNames.get(i))){
                        table.setRowSelectionInterval(i,i);
                        break;
                    }
                    i+=1;
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(494, 20, 110, 42);
        contentPane.add(btnNewButton);

        table.setEnabled(false);
        table.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        contentPane.add(table);
        table.setRowSelectionAllowed(true);
        table.setSurrendersFocusOnKeystroke(false);
        table.setFont(new Font("Tahoma", Font.PLAIN, 17));
        table.setBounds(2, 26, 450, 400);
        table.setRowHeight(20);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane.setBounds(38, 74, 802, 505);
        getContentPane().add(scrollPane);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchEntry s=new SearchEntry();
                s.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 608, 103, 30);
        contentPane.add(btnNewButton_1);
        scrollPane.setVisible(true);
    }

}


