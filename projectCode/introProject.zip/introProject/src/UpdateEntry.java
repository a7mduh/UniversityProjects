import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.Color;
import java.awt.Font;
import javax.swing.border.BevelBorder;
import javax.swing.JButton;
import java.awt.SystemColor;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateEntry extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdateEntry frame = new UpdateEntry();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UpdateEntry() {
        setTitle("Update entry");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        JButton btnNewButton = new JButton("Update Movie");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateMovie upd=new UpdateMovie();
                upd.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setBackground(UIManager.getColor("activeCaption"));
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton.setBounds(52, 208, 181, 94);
        contentPane.add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Update Studio\r\n");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateStudio us=new UpdateStudio();
                us.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_1.setBounds(301, 208, 176, 94);
        contentPane.add(btnNewButton_1);
        JButton btnNewButton_2 = new JButton("Update Persons");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdatePersons ud=new UpdatePersons();
                ud.setVisible(true);
                dispose();
            }
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_2.setBounds(554, 208, 176, 94);
        contentPane.add(btnNewButton_2);
        JButton btnNewButton_3 = new JButton("Back");
        btnNewButton_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                app back=new app();
                back.setVisible(true);
                dispose();
            }
        });
        btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_3.setBounds(10, 601, 107, 37);
        contentPane.add(btnNewButton_3);
    }
}
