public class mainClass
{
    public static void main(String[] args) {
        Signin adminHome = new Signin();
        adminHome.setVisible(true);
        //Database d = new Database();
        //d.updateMovie("ghhhh","", ""," aa", " aa","zz","zz","zz");
        // add movie
        // d.addMovie("ghh","ahmed", " zayed"," aa", " aa","","","");
        // get names for editing or searching
        // System.out.println(d.getNames());
    }
}