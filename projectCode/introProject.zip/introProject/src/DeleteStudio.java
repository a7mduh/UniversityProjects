import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class DeleteStudio extends JFrame {

    private JPanel contentPane;
    Database d = new Database();
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    DeleteMovie frame = new DeleteMovie();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public DeleteStudio() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Please select which studio to delete");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        lblNewLabel.setBounds(238, 10, 458, 62);
        contentPane.add(lblNewLabel);
        JComboBox comboBox = new JComboBox();
        comboBox.setBounds(196, 87, 437, 62);
        contentPane.add(comboBox);
        JButton btnNewButton = new JButton("Delete studio");
        ArrayList<String> movieNames = d.getStudio();
        int index = movieNames.size();
        int i = 0;
        while (i<index){
            String added = movieNames.get(i);
            comboBox.addItem(added);
            i+=1;
        }
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                d.deleteStudio(comboBox.getSelectedItem().toString());
                JOptionPane.showMessageDialog(null, "You have successfully Deleted a Studio");

                DeleteStudio del=new DeleteStudio();
                del.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(352, 183, 158, 42);
        contentPane.add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteEntry del=new DeleteEntry();
                del.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 575, 114, 42);
        contentPane.add(btnNewButton_1);
    }
}

