import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JToggleButton;

public class addPerson extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTable table;
    JToggleButton tglbtnNewToggleButton, tglbtnProducer, tglbtnActor;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    addPerson frame = new addPerson();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public addPerson() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        tglbtnNewToggleButton = new JToggleButton("Director");
        tglbtnNewToggleButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        tglbtnNewToggleButton.setBounds(125, 262, 147, 36);
        contentPane.add(tglbtnNewToggleButton);
        tglbtnProducer = new JToggleButton("Producer");
        tglbtnProducer.setFont(new Font("Tahoma", Font.PLAIN, 16));
        tglbtnProducer.setBounds(282, 260, 147, 36);
        contentPane.add(tglbtnProducer);
        tglbtnActor = new JToggleButton("Actor");
        tglbtnActor.setFont(new Font("Tahoma", Font.PLAIN, 16));
        tglbtnActor.setBounds(439, 260, 147, 36);
        contentPane.add(tglbtnActor);
        JLabel lblNewLabel = new JLabel("Please fill the information:");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        lblNewLabel.setBounds(306, 10, 293, 70);
        contentPane.add(lblNewLabel);
        JLabel lblNewLabel_1 = new JLabel("Name:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(45, 107, 184, 47);
        contentPane.add(lblNewLabel_1);
        JLabel lblNewLabel_2 = new JLabel("Date of birthday:");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel_2.setBounds(45, 188, 184, 47);
        contentPane.add(lblNewLabel_2);
        textField = new JTextField();
        textField.setBounds(306, 118, 193, 29);
        contentPane.add(textField);
        textField.setColumns(10);
        textField_1 = new JTextField();
        textField_1.setBounds(306, 199, 193, 29);
        contentPane.add(textField_1);
        textField_1.setColumns(10);
        JButton btnNewButton = new JButton("Add");
        Database d = new Database();

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (textField.getText().equals("") || textField_1.getText().equals("") )
                {
                    JOptionPane.showMessageDialog(null, "You have left one or more empty fields!");
                }
                else if (!tglbtnNewToggleButton.isSelected() && !tglbtnProducer.isSelected() && !tglbtnActor.isSelected())
                {
                    JOptionPane.showMessageDialog(null, "Please choose a job");
                }
                else
                {
                    if(tglbtnNewToggleButton.isSelected())
                        d.addDirector(textField.getText(),textField_1.getText());
                    if (tglbtnProducer.isSelected())
                        d.addProducer(textField.getText(),textField_1.getText());
                    if (tglbtnActor.isSelected())
                        d.addActor(textField.getText(),textField_1.getText());
                    JOptionPane.showMessageDialog(null, "You have successfully added a person");
                    addPerson update=new addPerson();
                    update.setVisible(true);
                    // textField.setText("");
                    // textField_1.setText("");
                    dispose();
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(637, 193, 142, 36);
        contentPane.add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEntryWindow Entry=new addEntryWindow();
                Entry.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(0, 619, 109, 29);
        contentPane.add(btnNewButton_1);
        JLabel lblNewLabel_4 = new JLabel("Job:");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel_4.setBounds(45, 268, 125, 20);
        contentPane.add(lblNewLabel_4);
        tglbtnProducer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tglbtnNewToggleButton.setSelected(false);
                tglbtnActor.setSelected(false);
            }
        });
        tglbtnNewToggleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tglbtnProducer.setSelected(false);
                tglbtnActor.setSelected(false);
            }
        });

        tglbtnActor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tglbtnNewToggleButton.setSelected(false);
                tglbtnProducer.setSelected(false);
            }
        });
    }
}

