import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Signin extends JFrame {

    private JPanel contentPane;
    private JTextField textField;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Signin frame = new Signin();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Signin() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Welcome to Movie System");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 34));
        lblNewLabel.setBounds(217, 27, 450, 77);
        contentPane.add(lblNewLabel);
        JLabel lblNewLabel_1 = new JLabel("Please sign in");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblNewLabel_1.setBounds(346, 149, 159, 39);
        contentPane.add(lblNewLabel_1);
        JLabel lblNewLabel_2 = new JLabel("Username:");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblNewLabel_2.setBounds(188, 202, 119, 48);
        contentPane.add(lblNewLabel_2);
        JLabel lblNewLabel_2_1 = new JLabel("Password:");
        lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblNewLabel_2_1.setBounds(188, 262, 119, 48);
        contentPane.add(lblNewLabel_2_1);
        textField = new JTextField();
        textField.setBounds(317, 212, 209, 38);
        contentPane.add(textField);
        textField.setColumns(10);
        JButton btnNewButton = new JButton("Sign in");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(358, 353, 131, 39);
        contentPane.add(btnNewButton);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(new Font("Tahoma", Font.PLAIN, 22));
        passwordField.setBounds(317, 267, 209, 38);
        contentPane.add(passwordField);
        passwordField.setVisible(true);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                char[] c=passwordField.getPassword();
                String p=new String(c);
                if (textField.getText().equals("Admin") && p.equals("qqqq"))
                {
                    app a=new app();
                    a.setVisible(true);
                    dispose();
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Wrong username or password ");
                    System.out.println(p);
                }
            }
        });
    }

}