import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class addMovie extends JFrame implements ListSelectionListener {

    private JPanel contentPane;
    private JTextField titleBox;
    private JTextField genreBox;
    private JTextField yearBox;
    private JLabel yearLabel;
    private JLabel timeLabel;
    private JTextField timeBox;
    private JLabel directorLabel;
    private JLabel producerLabel;
    private JLabel studioLabel;
    private JLabel actorsLabel;
    private JButton addEntryBtn;
    private JLabel introLabel;
    private JComboBox comboBox;
    private JComboBox comboBox_1;
    String text;
    Database d = new Database();
    String strings ="";
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    addMovie frame = new addMovie();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public addMovie() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        introLabel = new JLabel("Please fill the information:");
        introLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        introLabel.setHorizontalAlignment(SwingConstants.CENTER);
        introLabel.setBounds(282, 10, 381, 34);
        contentPane.add(introLabel);

        JLabel titleLabel = new JLabel("Title:");
        titleLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        titleLabel.setBounds(118, 59, 61, 16);
        contentPane.add(titleLabel);

        JLabel genreLabel = new JLabel("Genre:");
        genreLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        genreLabel.setBounds(118, 108, 61, 16);
        contentPane.add(genreLabel);

        yearLabel = new JLabel("Year:");
        yearLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        yearLabel.setBounds(118, 168, 61, 16);
        contentPane.add(yearLabel);

        timeLabel = new JLabel("Running time:");
        timeLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        timeLabel.setBounds(93, 222, 125, 16);
        contentPane.add(timeLabel);

        directorLabel = new JLabel("Director:");
        directorLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        directorLabel.setBounds(118, 276, 100, 16);
        contentPane.add(directorLabel);

        producerLabel = new JLabel("Producers:");
        producerLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        producerLabel.setBounds(114, 420, 86, 16);
        contentPane.add(producerLabel);

        studioLabel = new JLabel("Studio:");
        studioLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        studioLabel.setBounds(118, 337, 61, 16);
        contentPane.add(studioLabel);

        actorsLabel = new JLabel("Actors:");
        actorsLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        actorsLabel.setBounds(118, 497, 61, 16);
        contentPane.add(actorsLabel);

        titleBox = new JTextField();
        titleBox.setBounds(249, 57, 390, 26);
        contentPane.add(titleBox);
        titleBox.setColumns(10);

        genreBox = new JTextField();
        genreBox.setColumns(10);
        genreBox.setBounds(249, 106, 390, 26);
        contentPane.add(genreBox);

        yearBox = new JTextField();
        yearBox.setColumns(10);
        yearBox.setBounds(249, 166, 390, 26);
        contentPane.add(yearBox);

        timeBox = new JTextField();
        timeBox.setColumns(10);
        timeBox.setBounds(249, 220, 390, 26);
        contentPane.add(timeBox);

        addEntryBtn = new JButton("Add movie");
        addEntryBtn.setFont(new Font("Tahoma", Font.PLAIN, 16));
        addEntryBtn.setBounds(358, 575, 174, 52);
        contentPane.add(addEntryBtn);


        JButton btnNewButton = new JButton("Back");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEntryWindow Entry=new addEntryWindow();
                Entry.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setBounds(10, 612, 91, 26);
        contentPane.add(btnNewButton);

        comboBox = new JComboBox();
        comboBox.setBounds(249, 276, 236, 40);
        contentPane.add(comboBox);

        ArrayList<String> directorNames = d.getDirector();
        int index = directorNames.size();
        int i = 0;
        while (i<index){
            String added = directorNames.get(i);
            comboBox.addItem(added);
            i+=1;
        }
        comboBox_1 = new JComboBox();
        comboBox_1.setBounds(249, 355, 236, 40);
        contentPane.add(comboBox_1);
        ArrayList<String> studioNames = d.getStudio();
        index = studioNames.size();
        i = 0;
        while (i<index){
            String added = studioNames.get(i);
            comboBox_1.addItem(added);
            i+=1;
        }
        ArrayList<String> producerNames = d.getProducer();
        index = producerNames.size();
        i = 0;
        String columnNames[] = new String[index];
        while(i<index){
            columnNames[i] = producerNames.get(i);
            i+=1;
        }
        JList list=new JList(columnNames);
        list.addListSelectionListener(this);
        list.setEnabled(true);



        list.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        contentPane.add(list);
        list.setFont(new Font("Tahoma", Font.PLAIN, 17));
        list.setBounds(2, 26, 450, 400);
        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane.setBounds(249, 413, 236, 62);
        getContentPane().add(scrollPane);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        ArrayList<String> actorsNames = d.getActor();
        index = actorsNames.size();
        i = 0;
        String columnNames2[] = new String[index];
        while(i<index){
            columnNames2[i] = actorsNames.get(i);
            i+=1;
        }

        JList list1=new JList(columnNames2);
        list1.addListSelectionListener(this);
        list1.setEnabled(true);
        list1.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        contentPane.add(list1);
        list1.setFont(new Font("Tahoma", Font.PLAIN, 17));
        list1.setBounds(2, 26, 450, 400);
        JScrollPane scrollPane1 = new JScrollPane(list1);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane1.setBounds(249, 490, 236, 62);
        getContentPane().add(scrollPane1);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        addEntryBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (titleBox.getText().equals("") || genreBox.getText().equals("") || yearBox.getText().equals("") || timeBox.getText().equals("") )
                {
                    JOptionPane.showMessageDialog(null, "You have left one or more empty fields!");
                }
                else
                {

                    // add movie
                    Object[] selected = list.getSelectedValues();

                    String selectedItems = "";

                    for(int i=0; i<selected.length;i++){

                        selectedItems += selected[i].toString()+", ";

                    }
                    Object[] selected2 = list1.getSelectedValues();

                    String selectedItems2 = "";

                    for(int i=0; i<selected2.length;i++){

                        selectedItems2 += selected2[i].toString()+", ";

                    }
                    d.addMovie(titleBox.getText(),selectedItems, selectedItems2, comboBox.getSelectedItem().toString(), comboBox_1.getSelectedItem().toString(),genreBox.getText(),yearBox.getText(),timeBox.getText());
                    JOptionPane.showMessageDialog(null, "You have successfully added a movie");
                    addMovie add=new addMovie();
                    add.setVisible(true);
                    dispose();
                }
            }
        });
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
// TODO Auto-generated method stub
    }
}

