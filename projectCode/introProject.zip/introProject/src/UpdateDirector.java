import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JTextField;

public class UpdateDirector extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    Database d = new Database();
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdateDirector frame = new UpdateDirector();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UpdateDirector() {
        setTitle("Update Director");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Please select a director to update");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel.setBounds(215, 60, 305, 51);
        contentPane.add(lblNewLabel);
        JComboBox comboBox = new JComboBox();
        comboBox.setBounds(225, 122, 294, 22);
        contentPane.add(comboBox);
        JLabel lblNewLabel_1 = new JLabel("Date of birth:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_1.setBounds(215, 229, 122, 25);
        contentPane.add(lblNewLabel_1);
        JButton btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdatePersons ud=new UpdatePersons();
                ud.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(10, 602, 110, 36);
        contentPane.add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Update");

        ArrayList<String> directorNames = d.getDirector();
        int index = directorNames.size();
        int i = 0;
        while (i<index){
            String added = directorNames.get(i);
            comboBox.addItem(added);
            i+=1;
        }

        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if( textField.getText().equals("") || textField_1.getText().equals(""))
                {
                    JOptionPane.showMessageDialog(null, "You have left one or more empty fields!");
                }
                else
                {
                    d.updateDirector(comboBox.getSelectedItem().toString(),textField.getText(),textField_1.getText());
                    JOptionPane.showMessageDialog(null, "You have successfully updated "+comboBox.getSelectedItem()+" data");
                    UpdateDirector ud=new UpdateDirector();
                    ud.setVisible(true);
                    dispose();
                }
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_1.setBounds(303, 310, 161, 76);
        contentPane.add(btnNewButton_1);
        textField = new JTextField();
        textField.setBounds(355, 183, 165, 30);
        contentPane.add(textField);
        textField.setColumns(10);
        JLabel lblNewLabel_2 = new JLabel("Name:");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(215, 183, 122, 36);
        contentPane.add(lblNewLabel_2);
        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(355, 231, 165, 30);
        contentPane.add(textField_1);
        JButton btnNewButton_2 = new JButton("Confirm selection");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String n=comboBox.getSelectedItem().toString();
                ArrayList<String> address = d.getDirectorr(n);
                //use this for the update method
                textField.setText(n);
                textField_1.setText(address.get(0));
            }
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_2.setBounds(559, 122, 165, 36);
        contentPane.add(btnNewButton_2);
    }

}
