import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class SearchMovie extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    Database d = new Database();
    String[] columns= {"Title", "Actors", "Producers", "Director", "Studio", "Genre", "Year", "Running Time"};


    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SearchMovie frame = new SearchMovie();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SearchMovie() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Search movie by name: ");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel.setBounds(91, 20, 177, 42);
        contentPane.add(lblNewLabel);
        textField = new JTextField();
        textField.setBounds(278, 20, 163, 42);
        contentPane.add(textField);
        textField.setColumns(10);
        JButton btnNewButton = new JButton("Search");

        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(494, 20, 110, 42);
        contentPane.add(btnNewButton);
        Database d = new Database();
        ArrayList<String> movieNames = d.getNames();
        String[] names = new String[movieNames.size()];
        int index = movieNames.size();
        String[][] data1 =new String[index][8];
        int i = 0;
        while (i<index){
            String added = movieNames.get(i);
            names[i] = added;
            ArrayList<String> movie = d.getMovie(names[i]);
            data1[i][0] = names[i];
            data1[i][1] = movie.get(0);
            data1[i][2] = movie.get(1);
            data1[i][3] = movie.get(2);
            data1[i][4] = movie.get(3);
            data1[i][5] = movie.get(4);
            data1[i][6] = movie.get(5);
            data1[i][7] = movie.get(6);

            i+=1;
        }

        JTable table =new JTable(data1, columns);



        table.setEnabled(false);
        table.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        contentPane.add(table);
        table.setRowSelectionAllowed(true);
        table.setSurrendersFocusOnKeystroke(false);
        table.setFont(new Font("Tahoma", Font.PLAIN, 17));
        table.setBounds(2, 26, 450, 400);
        table.setRowHeight(20);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane.setBounds(38, 74, 802, 505);
        getContentPane().add(scrollPane);
        JButton btnNewButton_1 = new JButton("Back");

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name=textField.getText();
                int i=0;
                int index = movieNames.size();
                while(i<index){
                    if (name.equals(movieNames.get(i))){
                        table.setRowSelectionInterval(i,i);
                        break;
                    }
                    i+=1;
                }
                // create a for loop and search in the array list
                //get the index if found
                // if found, table.setSelectedIndex..
                //else, message not found
            }
        });
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchEntry s=new SearchEntry();
                s.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 608, 103, 30);
        contentPane.add(btnNewButton_1);
        scrollPane.setVisible(true);
    }

}
