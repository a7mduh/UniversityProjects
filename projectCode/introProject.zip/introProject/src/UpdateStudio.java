import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JTextField;

public class UpdateStudio extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    Database d = new Database();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdateStudio frame = new UpdateStudio();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UpdateStudio() {
        setTitle("Update Studio");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Please select a studio to update");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel.setBounds(215, 60, 305, 51);
        contentPane.add(lblNewLabel);
        JComboBox comboBox = new JComboBox();
        comboBox.setBounds(225, 105, 283, 35);
        contentPane.add(comboBox);

        ArrayList<String> movieNames = d.getStudio();
        int index = movieNames.size();
        int i = 0;
        while (i<index){
            String added = movieNames.get(i);
            comboBox.addItem(added);
            i+=1;
        }

        JButton btnNewButton_1 = new JButton("Update");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if( textField.getText().equals("") || textField_1.getText().equals(""))
                {
                    JOptionPane.showMessageDialog(null, "You have left one or more empty fields!");
                }
                else
                {
                    d.updateStudio(comboBox.getSelectedItem().toString(),textField.getText(),textField_1.getText());
                    JOptionPane.showMessageDialog(null, "You have successfully updated "+comboBox.getSelectedItem()+" data");
                    UpdateStudio ud=new UpdateStudio();
                    ud.setVisible(true);
                    dispose();
                }
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_1.setBounds(282, 304, 161, 76);
        contentPane.add(btnNewButton_1);
        JLabel lblNewLabel_1 = new JLabel("Studio Name:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(145, 186, 117, 35);
        contentPane.add(lblNewLabel_1);
        JLabel lblNewLabel_1_1 = new JLabel("Studio Address");
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel_1_1.setBounds(145, 242, 117, 35);
        contentPane.add(lblNewLabel_1_1);
        textField = new JTextField();
        textField.setBounds(282, 196, 208, 35);
        contentPane.add(textField);
        textField.setColumns(10);
        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(282, 242, 208, 35);
        contentPane.add(textField_1);
        JButton btnNewButton = new JButton("Back");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(10, 602, 110, 36);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateEntry ud=new UpdateEntry();
                ud.setVisible(true);
                dispose();
            }
        });
        JButton btnNewButton_2 = new JButton("Confirm selection");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String n=comboBox.getSelectedItem().toString();
                ArrayList<String>  address = d.getStudioo(n);
                //use this for the update method
                textField.setText(n);
                textField_1.setText(address.get(0));
            }
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_2.setBounds(559, 122, 165, 36);
        contentPane.add(btnNewButton_2);
    }
}

