import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class SearchPerson extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    String[][] data= {{"a","a","a"},{"a","a","a"}};
    String[] columns= {"Name", "Date of birthday", "Job"};

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SearchPerson frame = new SearchPerson();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SearchPerson() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Search person by name: ");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel.setBounds(63, 20, 205, 42);
        contentPane.add(lblNewLabel);
        textField = new JTextField();
        textField.setBounds(278, 20, 163, 42);
        contentPane.add(textField);
        textField.setColumns(10);
        JButton btnNewButton = new JButton("Search");

        Database d = new Database();
        ArrayList<String> actorNames = d.getActor();
        String[] names = new String[actorNames.size()];

        ArrayList<String> producerNames = d.getProducer();
        String[] names1 = new String[producerNames.size()];

        ArrayList<String> directorNames = d.getDirector();
        String[] names2 = new String[directorNames.size()];

        int index = actorNames.size();
        int index1 = producerNames.size();
        int index2 = directorNames.size();
        String[][] data1 =new String[index+index1+index2][3];
        int i = 0;
        String added = "";
        String totalNames = "";
        while (i<index){
            added = actorNames.get(i);
            totalNames += added;
            names[i] = added;
            ArrayList<String> actor = d.getActorr(added);
            data1[i][0] = names[i];
            data1[i][1] = actor.get(0);
            data1[i][2] = "Actor";
            i+=1;
        }
        int z=i;
        added ="";
        int a = 0;
        while (i<index+z){
            added = producerNames.get(a);
            totalNames += added;
            names1[a] = added;
            ArrayList<String> movie = d.getProducerr(added);
            data1[i][0] = names1[a];
            data1[i][1] = movie.get(0);
            data1[i][2] = "Producer";
            i+=1;
            a+=1;
        }
        z=i;
        added ="";
        a=0;
        while (i<index+z){
            added = directorNames.get(a);
            totalNames += added;
            names2[a] = added;
            ArrayList<String> movie = d.getDirectorr(added);
            data1[i][0] = names2[a];
            data1[i][1] = movie.get(0);
            data1[i][2] = "Director";
            i+=1;
            a+=1;
        }

        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(494, 20, 110, 42);
        contentPane.add(btnNewButton);
        JTable table=new JTable(data1, columns);
        table.setEnabled(false);
        table.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        contentPane.add(table);
        table.setRowSelectionAllowed(true);
        table.setSurrendersFocusOnKeystroke(false);
        table.setFont(new Font("Tahoma", Font.PLAIN, 17));
        table.setBounds(2, 26, 450, 400);
        table.setRowHeight(20);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane.setBounds(38, 74, 802, 505);
        getContentPane().add(scrollPane);
        JButton btnNewButton_1 = new JButton("Back");

        String finalTotalNames = totalNames;
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name=textField.getText();
                int i=0;
                int index = actorNames.size();
                while(i<index){
                    if (name.equals(names[i])){
                        table.setRowSelectionInterval(i,i);
                        break;
                    }
                    i+=1;
                }
                index = producerNames.size();
                int z=i;
                int a =0;
                while(i<index+z){
                    if (name.equals(names1[a])){
                        table.setRowSelectionInterval(i,i);
                        break;
                    }
                    a+=1;
                    i+=1;
                }
                index = directorNames.size();
                z=i;
                a =0;
                while(i<index+z){
                    if (name.equals(names2[a])){
                        table.setRowSelectionInterval(i,i);
                        break;
                    }
                    a+=1;
                    i+=1;
                }
            }
        });
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchEntry s=new SearchEntry();
                s.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 608, 103, 30);
        contentPane.add(btnNewButton_1);
        scrollPane.setVisible(true);
    }

}

