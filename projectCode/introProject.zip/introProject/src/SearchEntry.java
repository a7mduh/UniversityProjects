import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SearchEntry extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SearchEntry frame = new SearchEntry();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SearchEntry() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JButton btnNewButton = new JButton("Search Movie");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchMovie s=new SearchMovie();
                s.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(48, 279, 169, 147);
        contentPane.add(btnNewButton);
        JButton btnSearchPerson = new JButton("Search Person");
        btnSearchPerson.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchPerson s=new SearchPerson();
                s.setVisible(true);
                dispose();
            }
        });
        btnSearchPerson.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnSearchPerson.setBounds(360, 279, 169, 147);
        contentPane.add(btnSearchPerson);
        JButton btnSearchStudio = new JButton("Search Studio");
        btnSearchStudio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchStudio s=new SearchStudio();
                s.setVisible(true);
                dispose();
            }
        });
        btnSearchStudio.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnSearchStudio.setBounds(674, 279, 169, 147);
        contentPane.add(btnSearchStudio);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                app s=new app();
                s.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 608, 103, 30);
        contentPane.add(btnNewButton_1);
    }

}
