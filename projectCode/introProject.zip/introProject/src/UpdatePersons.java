import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdatePersons extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdatePersons frame = new UpdatePersons();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UpdatePersons() {
        setTitle("Update persons");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        JButton btnNewButton = new JButton("Update Actors");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateActor ud=new UpdateActor();
                ud.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnNewButton.setBounds(68, 278, 177, 86);
        contentPane.add(btnNewButton);
        JButton btnUpdateDirectors = new JButton("Update Directors");
        btnUpdateDirectors.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateDirector ud=new UpdateDirector();
                ud.setVisible(true);
                dispose();
            }
        });
        btnUpdateDirectors.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnUpdateDirectors.setBounds(314, 278, 205, 86);
        contentPane.add(btnUpdateDirectors);
        JButton btnUpdateProducers = new JButton("Update Producers");
        btnUpdateProducers.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateProducer up=new UpdateProducer();
                up.setVisible(true);
                dispose();
            }
        });
        btnUpdateProducers.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnUpdateProducers.setBounds(607, 278, 191, 86);
        contentPane.add(btnUpdateProducers);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 591, 101, 34);
        contentPane.add(btnNewButton_1);
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateEntry back=new UpdateEntry();
                back.setVisible(true);
                dispose();
            }
        });

    }
}

