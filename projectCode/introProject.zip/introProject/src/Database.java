import javax.swing.*;
import java.sql.*;
import java.util.*;
public class Database
{
    static Connection con = connect();
    public static Connection connect() {
        System.out.println("Connecting...");
        Connection con = null;
        try {
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:database.db");
            System.out.println("connected");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e+"");
        }

        return con;
    }
    //ADD Movie
    public void addMovie(String name, String actors, String producers, String directors, String studio, String Genre, String Year, String RunningTime) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "INSERT INTO Movie(Name, Actors, Producers, Director, Studio, Genre, Year, RunningTime) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            ps = con2.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, actors);
            ps.setString(3, producers);
            ps.setString(4, directors);
            ps.setString(5, studio);
            ps.setString(6, Genre);
            ps.setString(7, Year);
            ps.setString(8, RunningTime);
            ps.execute();
            System.out.println("Data has been inserted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void addProducer(String name,String dateOfBirthday) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "INSERT INTO Producers(Name,dateOfBirthday) VALUES(?,?)";
            ps = con2.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, dateOfBirthday);
            ps.execute();
            System.out.println("Data has been inserted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void addDirector(String name, String dateOfBirthday) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "INSERT INTO Director(Name, dateOfBirthday) VALUES(?,?)";
            ps = con2.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, dateOfBirthday);
            ps.execute();
            System.out.println("Data has been inserted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void addActor(String name, String dateOfBirthday) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "INSERT INTO Actors(Name, dateOfBirthday) VALUES(?,?)";
            ps = con2.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, dateOfBirthday);
            ps.execute();
            System.out.println("Data has been inserted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void addStudio(String name, String address) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "INSERT INTO Studio(Name,address) VALUES(?,?)";
            ps = con2.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, address);
            ps.execute();
            System.out.println("Data has been inserted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public ArrayList<String> getNames() {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Movie";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("Name"));

            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getProducer() {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Producers";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("Name"));

            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getDirector() {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Director";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("Name"));

            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getActor() {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Actors";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("Name"));

            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getStudio() {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Studio";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("Name"));

            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getMovie(String isim) {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Movie WHERE Name='"+isim+"'";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("Actors"));
                names.add(rs.getString("Producers"));
                names.add(rs.getString("Director"));
                names.add(rs.getString("Studio"));
                names.add(rs.getString("Genre"));
                names.add(rs.getString("Year"));
                names.add(rs.getString("RunningTIme"));

            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getStudioo(String isim) {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Studio WHERE Name='"+isim+"'";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("address"));
            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getActorr(String isim) {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Actors WHERE Name='"+isim+"'";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("dateOfBirthday"));
            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getProducerr(String isim) {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Producers WHERE Name='"+isim+"'";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("dateOfBirthday"));
            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
    public ArrayList<String> getDirectorr(String isim) {
        Connection con2 = connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> names = new ArrayList<String>();
        try {
            String sql = "SELECT * FROM Director WHERE Name='"+isim+"'";
            ps = con2.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("dateOfBirthday"));
            }
            return names;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }

    public void deleteMovie(String name) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "DELETE FROM Movie WHERE Name = '"+name+"'";
            ps = con2.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("Movie "+name+" has been Deleted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void deleteProducer(String name) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "DELETE FROM Producers WHERE Name = '"+name+"'";
            ps = con2.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("Movie "+name+" has been Deleted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void deleteDirector(String name) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "DELETE FROM Director WHERE Name = '"+name+"'";
            ps = con2.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("Movie "+name+" has been Deleted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void deleteActor(String name) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "DELETE FROM Actors WHERE Name = '"+name+"'";
            ps = con2.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("Movie "+name+" has been Deleted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    public void deleteStudio(String name) {
        Connection con2 = Database.con;
        PreparedStatement ps = null;
        try {
            String sql = "DELETE FROM Studio WHERE Name = '"+name+"'";
            ps = con2.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("Movie "+name+" has been Deleted");

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public void updateMovie(String name, String name2,String actors, String producers, String directors, String studio, String Genre, String Year, String RunningTime) {
        deleteMovie(name);
        addMovie(name2,actors,producers,directors,studio,Genre,Year,RunningTime);


    }
    public void updateProducer(String name, String name2,String dateOfBirthday) {
        deleteProducer(name);
        addProducer(name2, dateOfBirthday);
    }
    public void updateDirector(String name, String name2, String dateOfBirthday) {
        deleteDirector(name);
        addDirector(name2, dateOfBirthday);
    }
    public void updateActor(String name, String name2, String dateOfBirthday) {
        deleteActor(name);
        addActor(name2, dateOfBirthday);
    }
    public void updateStudio(String name, String name2, String address) {
        deleteStudio(name);
        addStudio(name2, address);
    }

}
