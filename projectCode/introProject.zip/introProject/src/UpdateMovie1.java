import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class UpdateMovie1 extends JFrame implements ListSelectionListener {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    Database d = new Database();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdateMovie1 frame = new UpdateMovie1("");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UpdateMovie1(String n) {
        setTitle("Update Movie");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        ArrayList<String> names = d.getMovie(n); // bring the name
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Title: ");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel.setBounds(10, 77, 147, 74);
        contentPane.add(lblNewLabel);
        textField = new JTextField();
        textField.setBounds(63, 109, 234, 20);
        contentPane.add(textField);
        textField.setColumns(10);
        JLabel lblNewLabel_1 = new JLabel("Actors:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_1.setBounds(10, 137, 72, 50);
        contentPane.add(lblNewLabel_1);
        JLabel lblNewLabel_2 = new JLabel("Producers:");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(10, 211, 147, 43);
        contentPane.add(lblNewLabel_2);
        JLabel lblNewLabel_3 = new JLabel("Director:");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_3.setBounds(10, 304, 113, 28);
        contentPane.add(lblNewLabel_3);
        JComboBox comboBox_2 = new JComboBox();
        comboBox_2.setBounds(94, 311, 205, 22);
        contentPane.add(comboBox_2);
        JLabel lblNewLabel_4 = new JLabel("Studio:");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_4.setBounds(10, 342, 72, 43);
        contentPane.add(lblNewLabel_4);
        JComboBox comboBox_3 = new JComboBox();
        comboBox_3.setBounds(77, 356, 220, 22);
        contentPane.add(comboBox_3);
        JLabel lblNewLabel_5 = new JLabel("Genre:");
        lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_5.setBounds(10, 395, 94, 28);
        contentPane.add(lblNewLabel_5);
        JLabel lblNewLabel_6 = new JLabel("Year:\r\n");
        lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_6.setBounds(10, 433, 60, 34);
        contentPane.add(lblNewLabel_6);
        JLabel lblNewLabel_7 = new JLabel("Run-time:");
        lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_7.setBounds(10, 477, 113, 22);
        contentPane.add(lblNewLabel_7);
        textField_1 = new JTextField();
        textField_1.setBounds(77, 404, 220, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);
        JButton btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateMovie ud=new UpdateMovie();
                ud.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(10, 584, 106, 34);
        contentPane.add(btnNewButton);
        textField_2 = new JTextField();
        textField_2.setBounds(73, 445, 234, 20);
        contentPane.add(textField_2);
        textField_2.setColumns(10);
        textField_3 = new JTextField();
        textField_3.setBounds(116, 477, 191, 20);
        contentPane.add(textField_3);
        textField_3.setColumns(10);
        JButton btnNewButton_1 = new JButton("Submit");



        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(323, 502, 147, 50);
        contentPane.add(btnNewButton_1);
        JLabel lblNewLabel_8 = new JLabel("Please enter the new data");
        lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 24));
        lblNewLabel_8.setBounds(261, 39, 360, 43);
        contentPane.add(lblNewLabel_8);

        ArrayList<String> actorNames = d.getActor();
        String actualName = names.get(0);
        int index = actorNames.size();
        int i = 0;
        int z = 0;
        String columnNames[] = new String[index];
        String columnNames2[] = new String[index];
        while(i<index){
            columnNames[i] = actorNames.get(i);
            if(actualName.contains(actorNames.get(i))){
                columnNames2[z] = columnNames[i];
                z+=1;
            }
            i+=1;
        }

        JList list=new JList(columnNames);
        int array[] = new int[z];
        i = 0;
        while(i<z){
            array[i] = i;
            i+=1;
        }
        list.setSelectedIndices(array);

        list.addListSelectionListener(this);
        list.setEnabled(true);
        list.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        contentPane.add(list);
        list.setFont(new Font("Tahoma", Font.PLAIN, 17));
        list.setBounds(2, 26, 450, 400);
        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane.setBounds(116, 137, 236, 73);
        getContentPane().add(scrollPane);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        ArrayList<String> producerNames = d.getProducer();
        String actualName1 = names.get(1);
        index = producerNames.size();
        i = 0;
        z = 0;
        String columnNames3[] = new String[index];
        String columnNames4[] = new String[index];
        while(i<index){
            columnNames3[i] = producerNames.get(i);
            if(actualName1.contains(producerNames.get(i))){
                columnNames4[z] = columnNames3[i];
                z+=1;
            }
            i+=1;
        }

        JList list1=new JList(columnNames3);
        int arra1y[] = new int[z];
        i = 0;
        while(i<z){
            arra1y[i] = i;
            i+=1;
        }
        list1.setSelectedIndices(arra1y);


        list1.addListSelectionListener(this);
        list1.setEnabled(true);
        list1.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        contentPane.add(list1);
        list1.setFont(new Font("Tahoma", Font.PLAIN, 17));
        list1.setBounds(2, 26, 450, 400);
        JScrollPane scrollPane1 = new JScrollPane(list1);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
        scrollPane1.setBounds(116, 220, 253, 74);
        getContentPane().add(scrollPane1);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);


        textField.setText(n);




        ArrayList<String> directorNames = d.getDirector();
        comboBox_2.addItem(names.get(2));

        index = directorNames.size();
        i = 0;
        while (i<index){

            String added = directorNames.get(i);
            if(!added.equals(names.get(2))) {
                comboBox_2.addItem(added);
            }
            i+=1;
        }

        ArrayList<String> studioNames = d.getStudio();
        comboBox_3.addItem(names.get(3));
        index = studioNames.size();
        i = 0;
        while (i<index){

            String added = studioNames.get(i);
            if(!added.equals(names.get(3))) {
                comboBox_3.addItem(added);
            }
            i+=1;
        }
        textField_1.setText(names.get(4));
        textField_2.setText(names.get(5));
        textField_3.setText(names.get(6));
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(textField.getText().equals("") || textField_1.getText().equals("") || textField_2.getText().equals("") || textField_3.getText().equals(""))
                {
                    JOptionPane.showMessageDialog(null, "You have left one or more empty fields!");
                }
                else
                {
                    Object[] selected = list.getSelectedValues();

                    String selectedItems = "";

                    for(int i=0; i<selected.length;i++){

                        selectedItems += selected[i].toString()+", ";

                    }
                    Object[] selected2 = list1.getSelectedValues();

                    String selectedItems2 = "";

                    for(int i=0; i<selected2.length;i++){

                        selectedItems2 += selected2[i].toString()+", ";

                    }
                    d.updateMovie(n,textField.getText(),selectedItems,selectedItems2,comboBox_2.getSelectedItem().toString(), comboBox_3.getSelectedItem().toString(),textField_1.getText(),textField_2.getText(),textField_3.getText());
                    JOptionPane.showMessageDialog(null, "You have successfully updated the data");
                    UpdateMovie1 ud=new UpdateMovie1(textField.getText());
                    ud.setVisible(true);
                    dispose();
                }
            }
        });
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
// TODO Auto-generated method stub
    }
}

