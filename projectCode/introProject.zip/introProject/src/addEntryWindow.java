import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addEntryWindow extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    addEntryWindow frame = new addEntryWindow();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public addEntryWindow() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JButton btnNewButton = new JButton("Add movie");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addMovie add=new addMovie();
                add.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(61, 250, 199, 113);
        contentPane.add(btnNewButton);
        JButton btnAddDirector = new JButton("Add person");
        btnAddDirector.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPerson add=new addPerson();
                add.setVisible(true);
                dispose();
            }
        });
        btnAddDirector.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnAddDirector.setBounds(360, 250, 176, 113);
        contentPane.add(btnAddDirector);
        JButton btnAaddMovieStudio = new JButton("Add movie studio");
        btnAaddMovieStudio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addMovieStudio add=new addMovieStudio();
                add.setVisible(true);
                dispose();
            }
        });
        btnAaddMovieStudio.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnAaddMovieStudio.setBounds(644, 250, 176, 113);
        contentPane.add(btnAaddMovieStudio);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                app back=new app();
                back.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 606, 105, 32);
        contentPane.add(btnNewButton_1);
    }

}


