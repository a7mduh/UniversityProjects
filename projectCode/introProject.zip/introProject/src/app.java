import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
public class app extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    app frame = new app();
                    frame.setVisible(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public app() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Welcome, Admin.");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNewLabel.setBounds(236, 10, 445, 77);
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblNewLabel);
        JButton addBtn = new JButton("Add entry");
        addBtn.setFont(new Font("Tahoma", Font.PLAIN, 16));
        addBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEntryWindow add = new addEntryWindow();
                add.setVisible(true);
                dispose();
            }
        });
        addBtn.setBounds(354, 81, 224, 56);
        contentPane.add(addBtn);
        JButton delBtn = new JButton("Delete entry");
        delBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteEntry del=new DeleteEntry();
                del.setVisible(true);
                dispose();
            }
        });
        delBtn.setFont(new Font("Tahoma", Font.PLAIN, 16));
        delBtn.setBounds(354, 175, 224, 56);
        contentPane.add(delBtn);
        JButton upBtn = new JButton("Update entry");
        upBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateEntry ud=new UpdateEntry();
                ud.setVisible(true);
                dispose();
            }
        });
        upBtn.setFont(new Font("Tahoma", Font.PLAIN, 16));
        upBtn.setBounds(354, 262, 224, 56);
        contentPane.add(upBtn);
        JButton searBtn = new JButton("Search entry");
        searBtn.setFont(new Font("Tahoma", Font.PLAIN, 16));
        searBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchEntry s=new SearchEntry();
                s.setVisible(true);
                dispose();
            }
        });
        searBtn.setBounds(354, 355, 224, 55);
        contentPane.add(searBtn);
        JButton btnNewButton = new JButton("Sign out");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You have successfully logged out");
                Signin a=new Signin();
                a.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(10, 10, 114, 40);
        contentPane.add(btnNewButton);
    }
}

