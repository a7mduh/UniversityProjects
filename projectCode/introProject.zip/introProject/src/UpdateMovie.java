
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class UpdateMovie extends JFrame implements ActionListener{
    public JComboBox comboBox = new JComboBox();
    Database d = new Database();
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UpdateMovie frame = new UpdateMovie();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void actionPerformed(ActionEvent e) {

    }

    /**
     * Create the frame.
     */
    public UpdateMovie() {
        setTitle("Update Movie");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Please select Movie to update");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel.setBounds(243, 11, 412, 146);
        contentPane.add(lblNewLabel);
        comboBox.setBounds(225, 126, 375, 75);
        contentPane.add(comboBox);
        JButton btnNewButton = new JButton("Submit");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // d.updateMovie();
                UpdateMovie1 ud=new UpdateMovie1( comboBox.getSelectedItem().toString());
                ud.setVisible(true);
                dispose();
            }
        });
        ArrayList<String> movieNames = d.getNames();
        int index = movieNames.size();
        int i = 0;
        while (i<index){
            String added = movieNames.get(i);
            comboBox.addItem(added);
            i+=1;
        }
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton.setBounds(275, 297, 231, 75);
        contentPane.add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateEntry ud=new UpdateEntry();
                ud.setVisible(true);
                dispose();
            }
        });

        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 602, 110, 36);
        contentPane.add(btnNewButton_1);
    }
}


