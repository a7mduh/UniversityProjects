import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class DeletePerson extends JFrame {

    private JPanel contentPane;
    Database d = new Database();
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    DeleteMovie frame = new DeleteMovie();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public DeletePerson() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 910, 685);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblNewLabel = new JLabel("Please select which person to delete");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        lblNewLabel.setBounds(238, 10, 458, 62);
        contentPane.add(lblNewLabel);
        JComboBox comboBox = new JComboBox();

        comboBox.setBounds(196, 87, 437, 62);
        contentPane.add(comboBox);
        JButton btnNewButton = new JButton("Delete director");

        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton.setBounds(352, 183, 158, 42);
        contentPane.add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteEntry del=new DeleteEntry();
                del.setVisible(true);
                dispose();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnNewButton_1.setBounds(10, 575, 114, 42);
        contentPane.add(btnNewButton_1);
        JLabel lblNewLabel_1 = new JLabel("Directors: ");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_1.setBounds(38, 97, 126, 52);
        contentPane.add(lblNewLabel_1);
        JComboBox comboBox_1 = new JComboBox();
        comboBox_1.setBounds(196, 235, 437, 62);
        contentPane.add(comboBox_1);
        JComboBox comboBox_2 = new JComboBox();
        comboBox_2.setBounds(196, 379, 437, 62);
        contentPane.add(comboBox_2);

        ArrayList<String> directorNames = d.getDirector();
        int index = directorNames.size();
        int i = 0;
        while (i<index){
            String added = directorNames.get(i);
            comboBox.addItem(added);
            i+=1;
        }

        ArrayList<String> producerNames = d.getProducer();
        index = producerNames.size();
        i = 0;
        while (i<index){
            String added = producerNames.get(i);
            comboBox_1.addItem(added);
            i+=1;
        }
        ArrayList<String> actorNames = d.getActor();
        index = actorNames.size();
        i = 0;
        while (i<index){
            String added = actorNames.get(i);
            comboBox_2.addItem(added);
            i+=1;
        }
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                d.deleteDirector(comboBox.getSelectedItem().toString());
                JOptionPane.showMessageDialog(null, "You have successuflly deleted "+ comboBox.getSelectedItem());
                DeletePerson del=new DeletePerson();
                del.setVisible(true);
                dispose();
            }
        });
        JButton btnDeleteProducers = new JButton("Delete producer");
        btnDeleteProducers.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                d.deleteProducer(comboBox_1.getSelectedItem().toString());
                JOptionPane.showMessageDialog(null, "You have successuflly deleted "+ comboBox_1.getSelectedItem());
                DeletePerson del=new DeletePerson();
                del.setVisible(true);
                dispose();
            }
        });
        btnDeleteProducers.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnDeleteProducers.setBounds(352, 323, 158, 42);
        contentPane.add(btnDeleteProducers);
        JButton btnDeleteActors = new JButton("Delete actor");
        btnDeleteActors.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                d.deleteActor(comboBox_2.getSelectedItem().toString());
                JOptionPane.showMessageDialog(null, "You have successuflly deleted "+ comboBox_2.getSelectedItem());
                DeletePerson del=new DeletePerson();
                del.setVisible(true);
                dispose();
            }
        });
        btnDeleteActors.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnDeleteActors.setBounds(352, 461, 158, 42);
        contentPane.add(btnDeleteActors);
        JLabel lblNewLabel_1_1 = new JLabel("producers: ");
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_1_1.setBounds(38, 235, 126, 52);
        contentPane.add(lblNewLabel_1_1);
        JLabel lblNewLabel_1_2 = new JLabel("actors: ");
        lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_1_2.setBounds(38, 379, 126, 52);
        contentPane.add(lblNewLabel_1_2);
    }
}