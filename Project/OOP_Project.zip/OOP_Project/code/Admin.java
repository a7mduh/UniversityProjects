
public class Admin extends Person{

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(String name, String user_id, String password) {
		super(name, user_id, password);
		// TODO Auto-generated constructor stub
	}
	
}
