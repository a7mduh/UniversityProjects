diagonal(Brd, Plr) :- Brd = [Plr,_,_,_,Plr,_,_,_,Plr]. %winning diagnoally
diagonal(Brd, Plr) :- Brd = [_,_,Plr,_,Plr,_,Plr,_,_].
column(Brd, Plr) :-Brd= [Plr,_,_,Plr,_,_,Plr,_,_]. %winning by columns
column(Brd, Plr) :-Brd= [_,Plr,_,_,Plr,_,_,Plr,_].
column(Brd, Plr) :-Brd= [_,_,Plr,_,_,Plr,_,_,Plr].
row(Brd, Plr) :- Brd=[Plr,Plr,Plr,_,_,_,_,_,_]. %winning by rows
row(Brd, Plr) :- Brd=[_,_,_,Plr,Plr,Plr,_,_,_].
row(Brd, Plr) :- Brd=[_,_,_,_,_,_,_,Plr,Plr,Plr].
win(Brd, Plr) :-diagonal(Brd, Plr). %winning by satysfying the above conditions
win(Brd, Plr) :- column(Brd, Plr).
win(Brd, Plr):- row(Brd, Plr).

display([A,B,C,D,E,F,G,H,I]) :- write([A,B,C]),nl,write([D,E,F]),nl, 
 write([G,H,I]),nl,nl. %printing the 3x3 grid

%applying the changes by the players
xmove([b,B,C,D,E,F,G,H,I], 1, [x,B,C,D,E,F,G,H,I]).
xmove([A,b,C,D,E,F,G,H,I], 2, [A,x,C,D,E,F,G,H,I]).
xmove([A,B,b,D,E,F,G,H,I], 3, [A,B,x,D,E,F,G,H,I]).
xmove([A,B,C,b,E,F,G,H,I], 4, [A,B,C,x,E,F,G,H,I]).
xmove([A,B,C,D,b,F,G,H,I], 5, [A,B,C,D,x,F,G,H,I]).
xmove([A,B,C,D,E,b,G,H,I], 6, [A,B,C,D,E,x,G,H,I]).
xmove([A,B,C,D,E,F,b,H,I], 7, [A,B,C,D,E,F,x,H,I]).
xmove([A,B,C,D,E,F,G,b,I], 8, [A,B,C,D,E,F,G,x,I]).
xmove([A,B,C,D,E,F,G,H,b], 9, [A,B,C,D,E,F,G,H,x]).
xmove(Board, _, Board) :- write('Illegal move.'), nl. %if the player chose wrong coordinates

omove([b,B,C,D,E,F,G,H,I], 1, [o,B,C,D,E,F,G,H,I]).
omove([A,b,C,D,E,F,G,H,I], 2, [A,o,C,D,E,F,G,H,I]).
omove([A,B,b,D,E,F,G,H,I], 3, [A,B,o,D,E,F,G,H,I]).
omove([A,B,C,b,E,F,G,H,I], 4, [A,B,C,o,E,F,G,H,I]).
omove([A,B,C,D,b,F,G,H,I], 5, [A,B,C,D,o,F,G,H,I]).
omove([A,B,C,D,E,b,G,H,I], 6, [A,B,C,D,E,o,G,H,I]).
omove([A,B,C,D,E,F,b,H,I], 7, [A,B,C,D,E,F,o,H,I]).
omove([A,B,C,D,E,F,G,b,I], 8, [A,B,C,D,E,F,G,o,I]).
omove([A,B,C,D,E,F,G,H,b], 9, [A,B,C,D,E,F,G,H,o]).
omove(Board, _, Board) :- write('Illegal move.'), nl.
%if the player chose wrong coordinates

play :-info,  playO([b,b,b,b,b,b,b,b,b]). %starting predicate

info :- %giving the players the indicies of the positions
  write('Please note that these are the positions: '),
  nl,
  display([1,2,3,4,5,6,7,8,9]).

win_check(Board, x):- win(Board, x), write('player x won'); playO(Board). %predicates to check the winner
win_check(Board, o):- win(Board, o), write('player o won'); playX(Board).
playO(Board) :- %player O predicate to input
     write('Player o enter a position (1-9):'),
  nl,
    read(N),
  omove(Board, N, Newboard),
  display(Newboard),
    win_check(Newboard, o).
playX(Board) :- %player x predicate to input
     write('Player x enter a position (1-9):'),
  nl,
    read(N),
  xmove(Board, N, Newboard),
  display(Newboard),
win_check(Newboard, x).
