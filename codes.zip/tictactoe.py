def print_board(board): #this function prints the board 
    print(board[0] + " | " + board[1] + " | " + board[2]) #first row of the board
    print("---------")
    print(board[3] + " | " + board[4] + " | " + board[5]) #second row of the board
    print("---------")
    print(board[6] + " | " + board[7] + " | " + board[8]) #third row of the board

def check_win(board, player): #this function recursively check if any player won
    win_combinations = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)] #all the possible winning combinations
    return check_win_recursive(board, win_combinations, player) #calls the recursive function

def check_win_recursive(board, win_combinations, player): #this funcition will iterate over all the winning combinations and checks if any player have any winning combination
    if len(win_combinations) == 0: #base case
        return False
    comb = win_combinations[0] 
    if board[comb[0]] == board[comb[1]] == board[comb[2]] == player: #check if the player has this combination
        return True
    else:
        return check_win_recursive(board, win_combinations[1:], player) #iterate over the next combination

def tic_tac_toe(): #function where it calls all other function and processes the game
    board = ["1","2","3","4","5","6","7","8","9"]
    players = ["O", "X"] # player O indictes first player, player X indicates second player
    current_player = players[0] #start with player O
    winner = None #variable to store the winner player
    counter=0 #counter to terminate the program if all the attempts are finished
    while True: #loop to keep asking the player one by one
        print_board(board) 
        print("Player", current_player)
        position = input("Enter position (1-9): ")
        if position.isdigit():
            position=int(position)-1
        else:
            print("Wrong input. Try again.")
            continue
        if position >8 or position<0:
            print("Wrong position! Try again with 1-9:")
            continue
        if board[position] == "O" or board[position] == "X": #check if the player selects a selected coordinate
            print("Position already occupied. Try again.")
            continue
        board[position] = current_player #update tje board
        counter+=1 #increamnt number of successful attempts
        if check_win(board, current_player): #check if the player won by this attempt 
            winner = current_player #update the winner
            break
        if counter==9: #check if no more attempts left
            break
        current_player = players[1] if current_player == players[0] else players[0] #move to the next player turn
    print_board(board)
    if winner:
        print("Congratulations! Player", winner, "has won.") #annouce the winner
    else:
        print("It's a tie.") #no winners

tic_tac_toe() #start the program
