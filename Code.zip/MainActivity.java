package com.example.securityproject;
import androidx.annotation.Nullable;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.content.Intent;
import android.graphics.Bitmap;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ImageView;
import com.example.securityproject.R.layout;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.annotation.NonNull;

import java.io.InputStream;


public final class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button button, proceed;
    private final int GALLERY_REQ_CODE = 1000;
    private final int CAMERA_REQ_CODE = 100;
    private final int CAMERA_REQUEST_CODE = 200;
    private final int PERMISSION_REQUEST_CODE = 300;
    private Bitmap selectedImageBitmap;

    int flag = 1;
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.setContentView(layout.activity_main);

        imageView = findViewById(R.id.capturedImage);
        button = findViewById(R.id.openCamera);

        Button btnGallery = findViewById(R.id.button);

        //handling the event of going to the editing activity
        proceed = findViewById(R.id.proceed);
        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditing();
            }
        });

        //handling the event of clicking the take picture button
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
                }
                else {
                    Intent open_camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(open_camera, CAMERA_REQ_CODE);
                    ContextWrapper cw = new ContextWrapper(getApplicationContext());
                }
            }
        });

        //handling the event of clicking the upload image button
        btnGallery.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, PERMISSION_REQUEST_CODE);
                }
                else
                {
                    Intent iGallery = new Intent(Intent.ACTION_GET_CONTENT);
                    iGallery.setType("image/*");
                    startActivityForResult(iGallery, GALLERY_REQ_CODE);
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) //dealing with activities
        {
            if (requestCode == CAMERA_REQ_CODE) //camera activity
            {
                flag = 0;
                Bitmap photo = (Bitmap)data.getExtras().get("data");
                photo = scaleDownBitmap(photo, 1000, this);
                selectedImageBitmap = photo;
                imageView.setImageBitmap(photo);
                proceed.setEnabled(true);
                uploadPhoto();
            }
            else if (requestCode == GALLERY_REQ_CODE) // gallery activity
            {
                try {
                    InputStream inputStream = getContentResolver().openInputStream(data.getData());
                    Bitmap bm = BitmapFactory.decodeStream(inputStream);
                    bm = scaleDownBitmap(bm, 1000, this);
                    selectedImageBitmap = bm;
                    imageView.setImageBitmap(bm);
                    proceed.setEnabled(true);
                    uploadPhoto();
                }catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }

    }
    //This will move the user to the editing page
    public void openEditing()
    {
        Intent intent = new Intent(this, Editing_activity.class);
        if (selectedImageBitmap != null && flag == 1) {
            intent.putExtra("imageGal", selectedImageBitmap);
        }
        else if (selectedImageBitmap != null && flag == 0)
        {
            intent.putExtra("imageBitmap", selectedImageBitmap);
        }
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Check camera permissions
        if (requestCode == CAMERA_REQUEST_CODE)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                // Permission granted, open camera
                Intent open_camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(open_camera, CAMERA_REQ_CODE);
            } else
            {
                // Permission denied, show message to user
                Toast.makeText(this, "Camera permission denied, please allow permission to take picture.", Toast.LENGTH_SHORT).show();
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA))
                {
                    // User selected 'Don't ask again', direct them to app settings
                    openAppSettings();
                }
            }
        }
        // Checking for Gallery permissions
        else if (requestCode == PERMISSION_REQUEST_CODE)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Intent iGallery = new Intent(Intent.ACTION_PICK);
                iGallery.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(iGallery, GALLERY_REQ_CODE);
            }
            else
            {
                Toast.makeText(this, "Photos permission denied, please allow permission to upload.", Toast.LENGTH_SHORT).show();
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_MEDIA_IMAGES))
                {
                    // User selected 'Don't ask again', direct them to app settings
                    openAppSettings();
                }
            }
        }
    }
    // Function to direct the user to the settings if he did not allow permissions
    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }
    // Function to reduce the quality of a picture to avoid crashes
    public static Bitmap scaleDownBitmap(Bitmap bitmap, int newWidth, Context context) {
        float densityMultiplier = context.getResources().getDisplayMetrics().density;
        int h = (int) (newWidth / densityMultiplier);
        int w = (int) (h * bitmap.getWidth() / ((double) bitmap.getHeight()));

        return Bitmap.createScaledBitmap(bitmap, w, h, true);
    }

    // function to upload the selected photo or pictured photo to the databse
    private void uploadPhoto() {
        boolean isImageInsertedOrUpdated = new DatabaseHelper(MainActivity.this).insertOrUpdateImage(selectedImageBitmap);

        if (isImageInsertedOrUpdated) {
            // The image was successfully inserted or updated
            Toast.makeText(this, "Image inserted successfully", Toast.LENGTH_SHORT).show();
        } else {
            // There was an issue with the insert or update operation
            Toast.makeText(this, "Failed to insert image", Toast.LENGTH_SHORT).show();
        }
    }
}
