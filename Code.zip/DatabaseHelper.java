package com.example.securityproject;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "image_db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "images";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_IMAGE_BLOB = "image_blob";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_IMAGE_BLOB + " BLOB)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    @SuppressLint("Range")
    public boolean insertOrUpdateImage(Bitmap imageBitmap) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if there's already an image in the database
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        if (cursor.getCount() > 0) {
            // If there's an existing image, update it
            cursor.moveToFirst();
            ContentValues updateValues = new ContentValues();
            byte[] imageBytes = getBytesFromBitmap(imageBitmap);
            updateValues.put(COLUMN_IMAGE_BLOB, imageBytes);
            int rowsUpdated = 0;
            if (cursor.getInt(cursor.getColumnIndex(COLUMN_ID)) >=0)
            {
                 rowsUpdated = db.update(TABLE_NAME, updateValues, COLUMN_ID + "=?", new String[]{String.valueOf(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)))});
            }
            cursor.close();
            db.close();
            return rowsUpdated > 0;
        } else {
            // If no existing image, insert a new one
            ContentValues insertValues = new ContentValues();
            byte[] imageBytes = getBytesFromBitmap(imageBitmap);
            insertValues.put(COLUMN_IMAGE_BLOB, imageBytes);
            long result = db.insert(TABLE_NAME, null, insertValues);
            cursor.close();
            db.close();
            return result != -1;
        }
    }


    public Bitmap getImage() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        Bitmap bitmap = null;
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") byte[] imageBytes = cursor.getBlob(cursor.getColumnIndex(COLUMN_IMAGE_BLOB));
            bitmap = getBitmapFromBytes(imageBytes);
        }

        cursor.close();
        db.close();
        return bitmap;
    }

    private byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

    private Bitmap getBitmapFromBytes(byte[] imageBytes) {
        return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
    }
}

